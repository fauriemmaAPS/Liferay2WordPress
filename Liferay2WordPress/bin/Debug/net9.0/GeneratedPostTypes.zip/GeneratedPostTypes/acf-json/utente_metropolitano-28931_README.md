# Utente Metropolitano

Custom Post Type generato da DDMStructure: `28931`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `28931`
- **Campi personalizzati**: 26
- **Taxonomies**: `28931_category` (gerarchica), `28931_tag` (non gerarchica)

## Campi

- **Nome Cognome** (`Nome_Cognome`): text
- **Ruolo** (`Ruolo`): select
- **Non Definito** (`option5041`): option
- **Sindaco** (`option9811`): option
- **Vice Sindaco** (`option6838`): option
- **Consigliere** (`option9812`): option
- **Capogruppo** (`option6839`): option
- **Indipendente** (`option5066`): option
- **Consigliere Delegato** (`option4923`): option
- **Commissario Prefettizio** (`option5181`): option
- **Sindaco Facente Funzioni** (`option7131`): option
- **Commissione Straordinaria** (`option7592`): option
- **** (`option7593`): option
- **Sito Web** (`Sito_Web`): text
- **Email** (`Email`): text
- **Indirizzo** (`Indirizzo`): text
- **Foto** (`Foto`): wcm-image
- **Descrizione** (`Descrizione`): ddm-text-html
- **Curriculum** (`Curriculum`): ddm-documentlibrary
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto`): checkbox
- **Consiglio Metropolitano** (`Consiglio_Metropolitano`): checkbox
- **Conferenza Metropolitana** (`Conferenza_Metropolitana`): checkbox
- **Sindaco Metropolitano** (`Sindaco_Metropolitano`): checkbox
- **Archivio Consiglio Metropolitano** (`Archivio_Consiglio_Metropolitano`): checkbox
