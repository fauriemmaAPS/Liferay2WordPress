<?php
/**
 * CMN Custom Post Types - Master Installation Script
 * Generated: 2025-12-04 13:58:39
 * Structures: 99
 *
 * Copy this file to your theme or create a plugin
 */

if (!defined('ABSPATH')) exit;

// Register all custom post types
add_action('init', function() {
    // Agenzia Stampa
    if (function_exists('register_cpt_45411')) register_cpt_45411();
    // Albo Pretorio
    if (function_exists('register_cpt_17193')) register_cpt_17193();
    // Albo Pretorio Scaduto
    if (function_exists('register_cpt_604250')) register_cpt_604250();
    // Area Funzionale 01
    if (function_exists('register_cpt_23891')) register_cpt_23891();
    // Attivazione
    if (function_exists('register_cpt_79755')) register_cpt_79755();
    // Attività
    if (function_exists('register_cpt_12601')) register_cpt_12601();
    // Attività AGID
    if (function_exists('register_cpt_5563458')) register_cpt_5563458();
    // Autorizzazione Unica Ambientale
    if (function_exists('register_cpt_76360')) register_cpt_76360();
    // Bandi di gare e contratti ai sensi dell\'art.37 del d.lgs.33/2013
    if (function_exists('register_cpt_156607')) register_cpt_156607();
    // Bando di concorso
    if (function_exists('register_cpt_45037')) register_cpt_45037();
    // Bando di gara
    if (function_exists('register_cpt_1017697')) register_cpt_1017697();
    // Bando di gara trasp
    if (function_exists('register_cpt_1012239')) register_cpt_1012239();
    // Bando di garan
    if (function_exists('register_cpt_29731')) register_cpt_29731();
    // CARD_AGID
    if (function_exists('register_cpt_14714559')) register_cpt_14714559();
    // CardBanner
    if (function_exists('register_cpt_5563290')) register_cpt_5563290();
    // Componenti del nucleo di Valutazione per l\'anno 2014
    if (function_exists('register_cpt_140355')) register_cpt_140355();
    // Componenti del Nucleo di Valutazione per l\'anno 2014
    if (function_exists('register_cpt_1399203')) register_cpt_1399203();
    // Comune
    if (function_exists('register_cpt_23611')) register_cpt_23611();
    // Comunicati
    if (function_exists('register_cpt_28641')) register_cpt_28641();
    // Comunicati stampa
    if (function_exists('register_cpt_12765579')) register_cpt_12765579();
    // Contacts
    if (function_exists('register_cpt_contacts')) register_cpt_contacts();
    // Contenuto Generale
    if (function_exists('register_cpt_37395')) register_cpt_37395();
    // Coordinate Progetti
    if (function_exists('register_cpt_5659945')) register_cpt_5659945();
    // Dati Tabella
    if (function_exists('register_cpt_31819')) register_cpt_31819();
    // Defibrillatori
    if (function_exists('register_cpt_5668314')) register_cpt_5668314();
    // Dichiarazioni sulla insussistenza
    if (function_exists('register_cpt_141816')) register_cpt_141816();
    // dirigenti (foia)
    if (function_exists('register_cpt_1656527')) register_cpt_1656527();
    // Elenco certificazioni di avvenuta bonifica
    if (function_exists('register_cpt_76954')) register_cpt_76954();
    // Elenco Partecipate
    if (function_exists('register_cpt_975443')) register_cpt_975443();
    // Email_Istituzionali
    if (function_exists('register_cpt_1971713')) register_cpt_1971713();
    // Enti di diritto privato controllati
    if (function_exists('register_cpt_158027')) register_cpt_158027();
    // Enti pubblici vigilati
    if (function_exists('register_cpt_154245')) register_cpt_154245();
    // Events
    if (function_exists('register_cpt_events')) register_cpt_events();
    // Graduatorie
    if (function_exists('register_cpt_77350')) register_cpt_77350();
    // hamef
    if (function_exists('register_cpt_109933')) register_cpt_109933();
    // Incarichi amministrativi di vertice
    if (function_exists('register_cpt_137899')) register_cpt_137899();
    // Interventi straordinari
    if (function_exists('register_cpt_227398')) register_cpt_227398();
    // Interventi straordinari e di emergenza ai sensi dell\'art.42
    if (function_exists('register_cpt_139310')) register_cpt_139310();
    // Inventory
    if (function_exists('register_cpt_inventory')) register_cpt_inventory();
    // Ipotesi A
    if (function_exists('register_cpt_79850')) register_cpt_79850();
    // Ipotesi B :
    if (function_exists('register_cpt_79895')) register_cpt_79895();
    // Ipotesi B1
    if (function_exists('register_cpt_79917')) register_cpt_79917();
    // Ipotesi B2
    if (function_exists('register_cpt_79927')) register_cpt_79927();
    // Issues Tracking
    if (function_exists('register_cpt_issues_tracking')) register_cpt_issues_tracking();
    // Lista menu destra
    if (function_exists('register_cpt_5563344')) register_cpt_5563344();
    // Meeting Minutes
    if (function_exists('register_cpt_meeting_minutes')) register_cpt_meeting_minutes();
    // Menù
    if (function_exists('register_cpt_8794282')) register_cpt_8794282();
    // Menu a Tendina (generico)
    if (function_exists('register_cpt_38592')) register_cpt_38592();
    // modello lista prova
    if (function_exists('register_cpt_819356')) register_cpt_819356();
    // Modulo Generale
    if (function_exists('register_cpt_34496')) register_cpt_34496();
    // Modulo Generale copia
    if (function_exists('register_cpt_3438606')) register_cpt_3438606();
    // Modulo Generale2
    if (function_exists('register_cpt_3433649')) register_cpt_3433649();
    // monitoraggio_procedimenti
    if (function_exists('register_cpt_1005793')) register_cpt_1005793();
    // News
    if (function_exists('register_cpt_12714')) register_cpt_12714();
    // News_Fix
    if (function_exists('register_cpt_2712079')) register_cpt_2712079();
    // nuovo rdf
    if (function_exists('register_cpt_3680950')) register_cpt_3680950();
    // Offerte di lavoro
    if (function_exists('register_cpt_38925')) register_cpt_38925();
    // opere
    if (function_exists('register_cpt_2247234')) register_cpt_2247234();
    // Piano Strategico
    if (function_exists('register_cpt_3497805')) register_cpt_3497805();
    // Piano Strategico Collapsible
    if (function_exists('register_cpt_3499767')) register_cpt_3499767();
    // PNRR_scuole
    if (function_exists('register_cpt_10154040')) register_cpt_10154040();
    // PNRR_scuole_sismico
    if (function_exists('register_cpt_10220251')) register_cpt_10220251();
    // progetti comuni
    if (function_exists('register_cpt_4325270')) register_cpt_4325270();
    // Progetti Comuni
    if (function_exists('register_cpt_5129177')) register_cpt_5129177();
    // Progetti-a.1 - Cultura come sviluppo
    if (function_exists('register_cpt_6586964')) register_cpt_6586964();
    // Progetti-a.2 - Scuole presidio di legalità ed integrazione
    if (function_exists('register_cpt_6607672')) register_cpt_6607672();
    // Progetti-a.3 - Autostrade digitali
    if (function_exists('register_cpt_6607674')) register_cpt_6607674();
    // Progetti-b.1 - Consumo di suolo Zero
    if (function_exists('register_cpt_6607676')) register_cpt_6607676();
    // Progetti-b.2 - Ossigeno Bene Comune
    if (function_exists('register_cpt_6607678')) register_cpt_6607678();
    // Progetti-b.3 - Città sicure
    if (function_exists('register_cpt_6607680')) register_cpt_6607680();
    // Provvedimenti Scaduti
    if (function_exists('register_cpt_3108817')) register_cpt_3108817();
    // Provvedimento Dirigente
    if (function_exists('register_cpt_211617')) register_cpt_211617();
    // Pubblicazioni
    if (function_exists('register_cpt_12619')) register_cpt_12619();
    // rdf
    if (function_exists('register_cpt_3660056')) register_cpt_3660056();
    // registro degli accessi
    if (function_exists('register_cpt_1722811')) register_cpt_1722811();
    // Rete museale metropolitana
    if (function_exists('register_cpt_80249')) register_cpt_80249();
    // Revisori dei conti
    if (function_exists('register_cpt_1970671')) register_cpt_1970671();
    // Servizi
    if (function_exists('register_cpt_12588')) register_cpt_12588();
    // Servizio
    if (function_exists('register_cpt_38174')) register_cpt_38174();
    // Servizio Viabilità
    if (function_exists('register_cpt_1654308')) register_cpt_1654308();
    // Siti Tematici
    if (function_exists('register_cpt_12569')) register_cpt_12569();
    // Sito Tematico
    if (function_exists('register_cpt_5671899')) register_cpt_5671899();
    // Società partecipate
    if (function_exists('register_cpt_158211')) register_cpt_158211();
    // Strutt2
    if (function_exists('register_cpt_8014255')) register_cpt_8014255();
    // struttura determine a contrarre
    if (function_exists('register_cpt_1732111')) register_cpt_1732111();
    // Struttura Leggi-tutto
    if (function_exists('register_cpt_23753')) register_cpt_23753();
    // struttura procedimenti
    if (function_exists('register_cpt_979058')) register_cpt_979058();
    // StrutturaArt27
    if (function_exists('register_cpt_1074220')) register_cpt_1074220();
    // StrutturaConsiglioMetropolitano
    if (function_exists('register_cpt_1243107')) register_cpt_1243107();
    // StrutturaConsulente
    if (function_exists('register_cpt_1261149')) register_cpt_1261149();
    // Suddivisione territoriale per competenza delle Procure della Repubblica
    if (function_exists('register_cpt_93059')) register_cpt_93059();
    // TEST_DEF
    if (function_exists('register_cpt_8071192')) register_cpt_8071192();
    // TipologiaProva
    if (function_exists('register_cpt_1338406')) register_cpt_1338406();
    // Titolo Progetto
    if (function_exists('register_cpt_5563439')) register_cpt_5563439();
    // To Do
    if (function_exists('register_cpt_to_do')) register_cpt_to_do();
    // URP
    if (function_exists('register_cpt_23939')) register_cpt_23939();
    // URP_CARD_AGID
    if (function_exists('register_cpt_5563349')) register_cpt_5563349();
    // Utente Metropolitano
    if (function_exists('register_cpt_28931')) register_cpt_28931();
    // WebTv
    if (function_exists('register_cpt_1480743')) register_cpt_1480743();
});

// Flush rewrite rules on activation
register_activation_hook(__FILE__, 'flush_rewrite_rules');
