# Provvedimento Dirigente

Custom Post Type generato da DDMStructure: `211617`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `211617`
- **Campi personalizzati**: 10
- **Taxonomies**: `211617_category` (gerarchica), `211617_tag` (non gerarchica)

## Campi

- **Numero** (`Numero`): text
- **Contenuto** (`Contenuto`): ddm-text-html
- **Numero Protocollo** (`Numero_Protocollo`): ddm-integer
- **Data rubricazione** (`Data_rubricazione`): ddm-date
- **Eventuale spesa prevista** (`Eventuale_spesa_prevista`): text
- **Estremi documenti** (`Estremi_documenti`): textarea
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Allegato Esterno** (`Allegato_Esterno`): text
- **Link** (`Link`): text
