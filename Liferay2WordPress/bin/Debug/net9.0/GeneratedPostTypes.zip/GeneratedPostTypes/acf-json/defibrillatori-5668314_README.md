# Defibrillatori

Custom Post Type generato da DDMStructure: `5668314`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `5668314`
- **Campi personalizzati**: 5
- **Taxonomies**: `5668314_category` (gerarchica), `5668314_tag` (non gerarchica)

## Campi

- **Modello defibrillatore** (`Modello_defibrillatore`): text
- **Descrizione sede** (`Descrizione_sede`): text
- **Citta** (`Codice_progetto`): text
- **Indirizzo** (`Indirizzo`): text
- **Ubicazione** (`Ubicazione`): text
