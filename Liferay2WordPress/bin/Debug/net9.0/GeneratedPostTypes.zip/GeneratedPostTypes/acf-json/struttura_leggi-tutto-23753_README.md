# Struttura Leggi-tutto

Custom Post Type generato da DDMStructure: `23753`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `23753`
- **Campi personalizzati**: 4
- **Taxonomies**: `23753_category` (gerarchica), `23753_tag` (non gerarchica)

## Campi

- **Prima sezione HTML** (`Prima_sezione_HTML`): ddm-text-html
- **Titolo seconda sezione** (`Titolo_seconda_sezione`): text
- **Seconda sezione HTML** (`Seconda_sezione_HTML`): ddm-text-html
- **Leggi Tutto** (`Leggi_Tutto`): checkbox
