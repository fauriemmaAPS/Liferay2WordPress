# TipologiaProva

Custom Post Type generato da DDMStructure: `1338406`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1338406`
- **Campi personalizzati**: 1
- **Taxonomies**: `1338406_category` (gerarchica), `1338406_tag` (non gerarchica)

## Campi

- **Testo** (`Testo1816`): text
