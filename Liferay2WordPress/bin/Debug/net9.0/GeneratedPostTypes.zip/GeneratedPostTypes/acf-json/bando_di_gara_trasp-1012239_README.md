# Bando di gara trasp

Custom Post Type generato da DDMStructure: `1012239`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1012239`
- **Campi personalizzati**: 21
- **Taxonomies**: `1012239_category` (gerarchica), `1012239_tag` (non gerarchica)

## Campi

- **Sottotitolo** (`Sottotitolo`): text
- **Data** (`Data_Pubblicazione`): ddm-date
- **Data di pubblicazione** (`Data_Di_Pubblicazione`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Contenuto breve** (`Abstract`): ddm-text-html
- **Contenuto Esteso** (`Contenuto_Esteso`): ddm-text-html
- **Cig** (`Cig`): textarea
- **oggetto del bando** (`oggetto_del_bando`): textarea
- **Struttura proponente** (`Ente_proponente`): textarea
- **Procedura scelta contraente** (`Procedura_scelta_contraente`): textarea
- **Aggiudicatario** (`Aggiudicatario`): textarea
- **Importo** (`Importo`): textarea
- **Tempi completamento fornitura** (`Tempi_completamento_fornitura`): textarea
- **Importo somme liquidate** (`Importo_somme_liquidate`): textarea
- **Determina a contrarre** (`Determina_a_contrarre`): textarea
- **Determina di liquidazione** (`Determina_di_liquidazione`): textarea
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno`): text
