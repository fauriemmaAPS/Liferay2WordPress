# Suddivisione territoriale per competenza delle Procure della Repubblica

Custom Post Type generato da DDMStructure: `93059`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `93059`
- **Campi personalizzati**: 3
- **Taxonomies**: `93059_category` (gerarchica), `93059_tag` (non gerarchica)

## Campi

- **di Napoli** (`di_Napoli`): ddm-text-html
- ** 	di Torre Annunziata ** (`__di_Torre_Annunziata_`): ddm-text-html
- **di Nola** (`di_Nola`): ddm-text-html
