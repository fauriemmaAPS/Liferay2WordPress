# rdf

Custom Post Type generato da DDMStructure: `3660056`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `3660056`
- **Campi personalizzati**: 11
- **Taxonomies**: `3660056_category` (gerarchica), `3660056_tag` (non gerarchica)

## Campi

- **Collegamento alla Pagina** (`Collegamento_alla_Pagina4000`): ddm-link-to-page
- **Immagine** (`Immagine3936`): wcm-image
- **Identificazione** (`dc11_identifier`): textarea
- **Definizione dipinto** (`dc11_subject`): textarea
- **Identificazione** (`dcterms_abstract`): textarea
- **Immagine** (`Immagine3525`): wcm-image
- **Secolo** (`dc11_date`): textarea
- **Materia e tecnica** (`dcterms_description`): textarea
- **Dimensioni** (`dcterms_format`): textarea
- **Autore** (`dc11_creator`): textarea
- **Note** (`Note`): textarea
