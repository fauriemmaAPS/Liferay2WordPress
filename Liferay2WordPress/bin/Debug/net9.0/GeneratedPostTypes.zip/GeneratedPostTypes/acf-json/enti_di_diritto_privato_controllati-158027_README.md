# Enti di diritto privato controllati

Custom Post Type generato da DDMStructure: `158027`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `158027`
- **Campi personalizzati**: 5
- **Taxonomies**: `158027_category` (gerarchica), `158027_tag` (non gerarchica)

## Campi

- **Enti di diritto privato controllati** (`Enti_di_diritto_privato_controllati`): ddm-text-html
- **Scheda** (`Scheda`): ddm-text-html
- **Bilancio** (`__Bilancio`): ddm-text-html
- **Statuto** (`Statuto`): ddm-text-html
- **ULTIMO AGGIORNAMENTO** (`ULTIMO_AGGIORNAMENTO`): ddm-date
