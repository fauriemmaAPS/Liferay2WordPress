# dirigenti (foia)

Custom Post Type generato da DDMStructure: `1656527`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1656527`
- **Campi personalizzati**: 10
- **Taxonomies**: `1656527_category` (gerarchica), `1656527_tag` (non gerarchica)

## Campi

- **Sottotitolo** (`Sottotitolo`): text
- **Data** (`Data_Pubblicazione`): ddm-date
- **Data di pubblicazione** (`Data_Di_Pubblicazione`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Contenuto breve** (`Abstract`): ddm-text-html
- **Contenuto Esteso** (`Contenuto_Esteso`): ddm-text-html
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto`): checkbox
