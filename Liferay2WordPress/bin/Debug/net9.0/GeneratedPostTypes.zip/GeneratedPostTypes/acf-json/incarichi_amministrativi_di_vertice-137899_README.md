# Incarichi amministrativi di vertice

Custom Post Type generato da DDMStructure: `137899`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `137899`
- **Campi personalizzati**: 7
- **Taxonomies**: `137899_category` (gerarchica), `137899_tag` (non gerarchica)

## Campi

- **Nominativo e incarico ricoperto** (`Nominativo_e__incarico_ricoperto`): ddm-text-html
- **Curriculum** (`Curriculum`): ddm-text-html
- **Retribuzione** (`Retribuzione`): ddm-text-html
- **Atto di nomina** (`Atto_di_nomina`): ddm-text-html
- **Dichiarazione sulle cause di incompatibilità ed inconferibilità** (`Dichiarazione_sulle_cause_di_incompatibilità__ed_inconferibilità`): ddm-text-html
- **Situazione patrimoniale 2015** (`Situazione_patrimoniale_2015`): ddm-text-html
- **Collegamento alla Pagina** (`Collegamento_alla_Pagina7641`): ddm-link-to-page
