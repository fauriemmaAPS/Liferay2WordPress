# Revisori dei conti

Custom Post Type generato da DDMStructure: `1970671`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1970671`
- **Campi personalizzati**: 5
- **Taxonomies**: `1970671_category` (gerarchica), `1970671_tag` (non gerarchica)

## Campi

- **Cognome e nome** (`Casella_di_Testo1669`): textarea
- **Atto di conferimento incarico** (`Atto_di_conferimento_incarico`): ddm-documentlibrary
- **Curriculum** (`Curriculum`): ddm-documentlibrary
- **Dati relativi allo svolgimento di incarichi...** (`Dati_relativi_allo_svolgimento_di_incarichi___`): ddm-documentlibrary
- **Compensi relativi al rapporto di lavoro** (`Compensi_relativi_al_rapporto_di_lavoro`): ddm-documentlibrary
