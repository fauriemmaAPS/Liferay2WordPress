# Menù

Custom Post Type generato da DDMStructure: `8794282`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `8794282`
- **Campi personalizzati**: 2
- **Taxonomies**: `8794282_category` (gerarchica), `8794282_tag` (non gerarchica)

## Campi

- **Testo** (`Testo`): text
- **Link** (`Link`): text
