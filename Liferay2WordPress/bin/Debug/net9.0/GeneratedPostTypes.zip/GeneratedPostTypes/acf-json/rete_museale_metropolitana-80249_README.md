# Rete museale metropolitana

Custom Post Type generato da DDMStructure: `80249`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `80249`
- **Campi personalizzati**: 5
- **Taxonomies**: `80249_category` (gerarchica), `80249_tag` (non gerarchica)

## Campi

- **1** (`1`): ddm-text-html
- **Nome** (`Nome`): ddm-text-html
- **Indirizzo** (`Indirizzo`): ddm-text-html
- **CAP** (`CAP`): ddm-text-html
- **Città** (`Città`): ddm-text-html
