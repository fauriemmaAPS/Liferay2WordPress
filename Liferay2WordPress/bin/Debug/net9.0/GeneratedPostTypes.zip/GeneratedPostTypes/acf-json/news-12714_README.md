# News

Custom Post Type generato da DDMStructure: `12714`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `12714`
- **Campi personalizzati**: 13
- **Taxonomies**: `12714_category` (gerarchica), `12714_tag` (non gerarchica)

## Campi

- **Abstract** (`Testo`): text
- **Link Esterno** (`Link_Esterno`): text
- **Contenuto News** (`Contenuto_News`): ddm-text-html
- **Data Evento** (`Data_Evento`): text
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Immagine di Primo Piano (880x300)** (`Immagine_di_Primo_Piano`): wcm-image
- **Immagine logo (90x90)** (`Immagine`): wcm-image
- **Visualizza in:** (`Visualizza_in_`): radio
- **Solo nel canale** (`option8591`): option
- **Primo Piano** (`option8592`): option
- **News di Sinistra** (`option8593`): option
- **News di Destra** (`option8594`): option
