# modello lista prova

Custom Post Type generato da DDMStructure: `819356`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `819356`
- **Campi personalizzati**: 8
- **Taxonomies**: `819356_category` (gerarchica), `819356_tag` (non gerarchica)

## Campi

- **Beneficiario** (`Beneficiario`): textarea
- **CF/P.IVA** (`CF_P_IVA`): textarea
- **Importo Complessivo** (`Importo_Complessivo`): ddm-decimal
- **Norma o titolo a base di attribuzione** (`Norma_o_titolo_a_base_di_attribuzione`): textarea
- **Ufficio** (`Ufficio`): textarea
- **Responsabile** (`Responsabile`): textarea
- **Modalita' per individuare il beneficiario** (`Modalita__per_individuare_il_beneficiario`): textarea
- **Data pubblicazione** (`Data_pubblicazione`): ddm-date
