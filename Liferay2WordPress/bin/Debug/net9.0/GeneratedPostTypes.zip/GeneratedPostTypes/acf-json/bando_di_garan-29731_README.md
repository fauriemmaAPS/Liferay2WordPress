# Bando di garan

Custom Post Type generato da DDMStructure: `29731`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `29731`
- **Campi personalizzati**: 11
- **Taxonomies**: `29731_category` (gerarchica), `29731_tag` (non gerarchica)

## Campi

- **Sottotitolo** (`Sottotitolo`): text
- **Data** (`Data_Pubblicazione`): ddm-date
- **Data di pubblicazione** (`Data_Di_Pubblicazione`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Contenuto Estesosss** (`Contenuto_Estesox`): ddm-text-html
- **nuovo cig** (`Cig`): text
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno`): text
