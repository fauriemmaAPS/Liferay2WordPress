# Comune

Custom Post Type generato da DDMStructure: `23611`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `23611`
- **Campi personalizzati**: 16
- **Taxonomies**: `23611_category` (gerarchica), `23611_tag` (non gerarchica)

## Campi

- **Stemma** (`Stemma`): wcm-image
- **Comune** (`Comune`): text
- **Superficie kmq** (`Superficie_kmq`): text
- **Popolazione** (`Popolazione`): text
- **Sito Web** (`Sito_Web`): text
- **Email** (`Email`): text
- **Indirizzo** (`Indirizzo`): text
- **Foto** (`Consigliere_Comunale`): wcm-image
- **Nome Cognome** (`CC_Nome_Cognome`): text
- **Ruolo** (`CC_Ruolo`): select
- **Sindaco** (`option8962`): option
- **Assessore** (`option8963`): option
- **Sito Web** (`CC_Sito_Web`): text
- **Email** (`CC_Email`): text
- **Indirizzo** (`CC_Indirizzo`): text
- **Curricculum Vitae** (`CC_Curricculum_Vitae`): ddm-documentlibrary
