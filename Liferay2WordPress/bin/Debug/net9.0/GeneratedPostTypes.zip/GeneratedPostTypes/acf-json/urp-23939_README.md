# URP

Custom Post Type generato da DDMStructure: `23939`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `23939`
- **Campi personalizzati**: 3
- **Taxonomies**: `23939_category` (gerarchica), `23939_tag` (non gerarchica)

## Campi

- **Titolo** (`Titolo`): text
- **Contenuto** (`Contenuto`): ddm-text-html
- **Form** (`Form`): checkbox
