# Agenzia Stampa

Custom Post Type generato da DDMStructure: `45411`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `45411`
- **Campi personalizzati**: 3
- **Taxonomies**: `45411_category` (gerarchica), `45411_tag` (non gerarchica)

## Campi

- **Numero Agenzia** (`Agenzia_N_`): text
- **Abstract** (`Abstract`): ddm-text-html
- **Testo agenzia** (`Contenuto_Esteso`): ddm-text-html
