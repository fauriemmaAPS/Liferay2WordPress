# Meeting Minutes

Custom Post Type generato da DDMStructure: `MEETING MINUTES`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `meeting_minutes`
- **Campi personalizzati**: 7
- **Taxonomies**: `meeting_minutes_category` (gerarchica), `meeting_minutes_tag` (non gerarchica)

## Campi

- **Attachment** (`attachment`): ddm-documentlibrary
- **Author** (`author`): text
- **Description** (`description`): textarea
- **Meeting Duration** (`duration`): text
- **Meeting Date** (`meetingDate`): ddm-date
- **Minutes** (`minutes`): textarea
- **Title** (`title`): text
