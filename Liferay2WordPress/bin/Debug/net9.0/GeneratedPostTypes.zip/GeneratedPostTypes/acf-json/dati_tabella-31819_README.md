# Dati Tabella

Custom Post Type generato da DDMStructure: `31819`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `31819`
- **Campi personalizzati**: 6
- **Taxonomies**: `31819_category` (gerarchica), `31819_tag` (non gerarchica)

## Campi

- **Nominativo** (`Nominativo`): text
- **Decorrenza** (`Decorrenza`): text
- **Scadenza** (`Scadenza`): text
- **Importo** (`Importo`): ddm-number
- **Data** (`Data2562`): ddm-date
- **Allegato** (`Allegati`): ddm-documentlibrary
