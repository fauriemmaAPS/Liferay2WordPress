# Società partecipate

Custom Post Type generato da DDMStructure: `158211`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `158211`
- **Campi personalizzati**: 5
- **Taxonomies**: `158211_category` (gerarchica), `158211_tag` (non gerarchica)

## Campi

- **Società partecipate** (`Società_partecipate`): ddm-text-html
- **Scheda** (`Scheda`): ddm-text-html
- **Bilancio** (`Bilancio`): ddm-text-html
- **Statuto** (`Statuto`): ddm-text-html
- **Ultimo aggiornamento** (`Ultimo_aggiornamento`): ddm-date
