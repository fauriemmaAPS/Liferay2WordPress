# hamef

Custom Post Type generato da DDMStructure: `109933`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `109933`
- **Campi personalizzati**: 2
- **Taxonomies**: `109933_category` (gerarchica), `109933_tag` (non gerarchica)

## Campi

- **Contatti** (`Contatti`): ddm-text-html
- **HTML** (`HTML4282`): ddm-text-html
