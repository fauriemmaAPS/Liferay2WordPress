# Ipotesi B2

Custom Post Type generato da DDMStructure: `79927`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `79927`
- **Campi personalizzati**: 2
- **Taxonomies**: `79927_category` (gerarchica), `79927_tag` (non gerarchica)

## Campi

- **Soggetto Responsabile  ** (`Soggetto_Responsabile__`): ddm-text-html
- **Autorità Compente  ** (`Autorità_Compente__`): ddm-text-html
