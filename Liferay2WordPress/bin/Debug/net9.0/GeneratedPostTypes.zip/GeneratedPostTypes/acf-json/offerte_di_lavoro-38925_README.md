# Offerte di lavoro

Custom Post Type generato da DDMStructure: `38925`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `38925`
- **Campi personalizzati**: 10
- **Taxonomies**: `38925_category` (gerarchica), `38925_tag` (non gerarchica)

## Campi

- **Sottotitolo** (`Sottotitolo`): text
- **Data** (`Data_Pubblicazione`): ddm-date
- **Scadenza** (`Scadenza`): ddm-date
- **Data di pubblicazione** (`Data_Di_Pubblicazione`): checkbox
- **Data di scadenza** (`Data_di_scadenza`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Informazioni** (`Abstract`): ddm-text-html
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
