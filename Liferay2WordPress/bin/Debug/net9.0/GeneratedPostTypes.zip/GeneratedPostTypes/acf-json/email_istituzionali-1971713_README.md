# Email_Istituzionali

Custom Post Type generato da DDMStructure: `1971713`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1971713`
- **Campi personalizzati**: 4
- **Taxonomies**: `1971713_category` (gerarchica), `1971713_tag` (non gerarchica)

## Campi

- **Area** (`Area`): textarea
- **Direzione** (`Direzione`): textarea
- **Ufficio** (`Ufficio`): textarea
- **Email** (`Email`): textarea
