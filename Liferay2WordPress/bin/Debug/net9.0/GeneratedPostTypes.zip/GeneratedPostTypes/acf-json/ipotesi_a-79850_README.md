# Ipotesi A

Custom Post Type generato da DDMStructure: `79850`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `79850`
- **Campi personalizzati**: 2
- **Taxonomies**: `79850_category` (gerarchica), `79850_tag` (non gerarchica)

## Campi

- **Soggetto Responsabile** (`Soggetto_Responsabile`): ddm-text-html
- **Autorità Compente** (`Autorità_Compente`): ddm-text-html
