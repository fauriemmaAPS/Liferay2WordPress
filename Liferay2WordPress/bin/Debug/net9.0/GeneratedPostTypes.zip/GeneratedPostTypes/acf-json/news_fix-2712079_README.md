# News_Fix

Custom Post Type generato da DDMStructure: `2712079`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `2712079`
- **Campi personalizzati**: 8
- **Taxonomies**: `2712079_category` (gerarchica), `2712079_tag` (non gerarchica)

## Campi

- **Immagine** (`Immagine`): text
- **Immagine2** (`Immagine2`): text
- **Titolo Banner Immagine** (`Titolo_Banner_Immagine`): text
- **Titolo Banner Immagine2** (`Titolo_Banner_Immagine2`): text
- **Titolo Link Immagine** (`Titolo_Link_Immagine`): text
- **Titolo Link Immagine2** (`Titolo_Link_Immagine2`): text
- **Collegamento Immagine** (`Collegamento_Immagine`): ddm-link-to-page
- **Collegamento Immagine2** (`Collegamento_Immagine2`): ddm-link-to-page
