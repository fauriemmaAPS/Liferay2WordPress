# WebTv

Custom Post Type generato da DDMStructure: `1480743`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1480743`
- **Campi personalizzati**: 7
- **Taxonomies**: `1480743_category` (gerarchica), `1480743_tag` (non gerarchica)

## Campi

- **Canale Youtube** (`Canale_Youtube`): text
- **Titolo Banner Video** (`Titolo_Banner_Video`): text
- **Collegamento banner** (`Collegamento_banner`): textarea
- **Immagine** (`Immagine`): text
- **Titolo Banner Immagine** (`Titolo_Banner_Immagine`): text
- **Titolo Link Immagine** (`Titolo_Link_Immagine`): text
- **Collegamento Immagine** (`Collegamento_Immagine`): ddm-link-to-page
