# Dichiarazioni sulla insussistenza

Custom Post Type generato da DDMStructure: `141816`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `141816`
- **Campi personalizzati**: 5
- **Taxonomies**: `141816_category` (gerarchica), `141816_tag` (non gerarchica)

## Campi

- **Cognome** (`Cognome`): ddm-text-html
- **Nome** (`Nome`): ddm-text-html
- **Incarico** (`Incarico`): ddm-text-html
- **Ente o società** (`Ente_o_società`): ddm-text-html
- **Dichiarazione** (`Dichiarazione`): ddm-text-html
