# opere

Custom Post Type generato da DDMStructure: `2247234`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `2247234`
- **Campi personalizzati**: 5
- **Taxonomies**: `2247234_category` (gerarchica), `2247234_tag` (non gerarchica)

## Campi

- **Autore** (`Autore`): ddm-link-to-page
- **Data di creazione** (`Data_di_creazione`): ddm-date
- **Aggiornamento** (`Aggiornamento`): ddm-date
- **Descrizione** (`Descrizione`): textarea
- **Immagine** (`Immagine5480`): wcm-image
