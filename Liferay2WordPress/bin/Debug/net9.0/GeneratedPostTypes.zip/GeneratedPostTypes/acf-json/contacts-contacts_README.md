# Contacts

Custom Post Type generato da DDMStructure: `CONTACTS`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `contacts`
- **Campi personalizzati**: 13
- **Taxonomies**: `contacts_category` (gerarchica), `contacts_tag` (non gerarchica)

## Campi

- **Company** (`company`): text
- **Email** (`email`): text
- **First Name** (`firstName`): text
- **Instant Messenger Service** (`imService`): select
- **AOL** (`aol`): option
- **Yahoo** (`yahoo`): option
- **GTalk** (`gtalk`): option
- **Instant Messenger** (`imUserName`): text
- **Job Title** (`jobTitle`): text
- **Last Name** (`lastName`): text
- **Notes** (`notes`): textarea
- **Phone (Mobile)** (`phoneMobile`): text
- **Phone (Office)** (`phoneOffice`): text
