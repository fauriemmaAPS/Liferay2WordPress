# StrutturaArt27

Custom Post Type generato da DDMStructure: `1074220`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1074220`
- **Campi personalizzati**: 30
- **Taxonomies**: `1074220_category` (gerarchica), `1074220_tag` (non gerarchica)

## Campi

- **CF o PIVA** (`CF_PIVA`): textarea
- **Tipo di Rapporto** (`Tipo_Rapporto`): select
- **Contributo** (`option25698`): option
- **Incarico professionale** (`option25699`): option
- **Consulenza** (`option25700`): option
- **Collaborazione** (`option25701`): option
- **Studio** (`option25702`): option
- **Ricerca** (`option25703`): option
- **Vantaggio economico** (`option8721`): option
- **Importo** (`Importo`): ddm-decimal
- **Norma o Titolo** (`Norma_Titolo`): textarea
- **Ufficio** (`Ufficio`): textarea
- **Responsabile del procedimento** (`Responsabile_Procedimento`): textarea
- **Modalità utilizzata per individuare il beneficiario** (`Modalita`): textarea
- **Data Pubblicazione** (`Data_Pubblicazione`): ddm-date
- **Data di Pubblicazione** (`Data_di_Pubblicazione`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Progetto** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno`): text
- **Curriculum** (`Nome_Allegato_cv`): text
- **Allegato** (`Allegato_cv`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento_alla_Pagina_cv`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno_cv`): text
- **Provvedimento** (`Provvedimento`): text
- **Allegato** (`Allegato_pr`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento_alla_Pagina_pr`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno_pr`): text
