# Elenco certificazioni di avvenuta bonifica

Custom Post Type generato da DDMStructure: `76954`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `76954`
- **Campi personalizzati**: 2
- **Taxonomies**: `76954_category` (gerarchica), `76954_tag` (non gerarchica)

## Campi

- **NUM** (`NUM`): ddm-text-html
- **AREA** (`AREA`): ddm-text-html
