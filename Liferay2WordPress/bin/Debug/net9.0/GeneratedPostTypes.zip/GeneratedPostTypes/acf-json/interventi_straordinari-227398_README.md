# Interventi straordinari

Custom Post Type generato da DDMStructure: `227398`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `227398`
- **Campi personalizzati**: 9
- **Taxonomies**: `227398_category` (gerarchica), `227398_tag` (non gerarchica)

## Campi

- **di concessione** (`di_concessione`): ddm-text-html
- **Nominativo beneficiario** (`Nominativo_beneficiario`): ddm-text-html
- ** P.IVA. o C.F. ** (`_P_IVA__o_C_F__`): ddm-text-html
- **Importo del vantaggio economico** (`Importo_del_vantaggio_economico`): ddm-text-html
- **Norma o titolo a base dell’attribuzione** (`Norma_o_titolo_a_base_dell_attribuzione`): ddm-text-html
- **Ufficio** (`Ufficio`): ddm-text-html
- **Funzionario o Dirigente Responsabile del procedimento** (`Funzionario_o_Dirigente_Responsabile_del_procedimento`): ddm-text-html
- **Progetto selezionato** (`Progetto_selezionato`): ddm-text-html
- **Modalità seguita per individuazione del beneficiario** (`Modalità_seguita_per_individuazione_del_beneficiario`): ddm-text-html
