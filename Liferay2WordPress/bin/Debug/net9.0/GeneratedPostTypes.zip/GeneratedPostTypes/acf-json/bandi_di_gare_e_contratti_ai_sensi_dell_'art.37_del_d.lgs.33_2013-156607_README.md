# Bandi di gare e contratti ai sensi dell\'art.37 del d.lgs.33/2013

Custom Post Type generato da DDMStructure: `156607`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `156607`
- **Campi personalizzati**: 4
- **Taxonomies**: `156607_category` (gerarchica), `156607_tag` (non gerarchica)

## Campi

- **TITOLO** (`TITOLO`): ddm-text-html
- **DESCRIZIONE** (`DESCRIZIONE`): ddm-text-html
- **DOCUMENTO PRINCIPALE** (`DOCUMENTO_PRINCIPALE`): ddm-text-html
- **AGGIORNAMENTO** (`AGGIORNAMENTO`): ddm-text-html
