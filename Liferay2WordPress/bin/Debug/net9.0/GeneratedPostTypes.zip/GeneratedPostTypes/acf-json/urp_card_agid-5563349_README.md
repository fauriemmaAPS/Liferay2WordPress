# URP_CARD_AGID

Custom Post Type generato da DDMStructure: `5563349`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `5563349`
- **Campi personalizzati**: 3
- **Taxonomies**: `5563349_category` (gerarchica), `5563349_tag` (non gerarchica)

## Campi

- **Icona** (`icona`): text
- **Descrizione** (`descrizione`): textarea
- **Collegamento alla Pagina** (`collegamento`): ddm-link-to-page
