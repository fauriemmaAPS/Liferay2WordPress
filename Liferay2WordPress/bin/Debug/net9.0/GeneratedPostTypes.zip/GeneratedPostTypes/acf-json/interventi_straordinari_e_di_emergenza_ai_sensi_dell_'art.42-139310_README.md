# Interventi straordinari e di emergenza ai sensi dell\'art.42

Custom Post Type generato da DDMStructure: `139310`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `139310`
- **Campi personalizzati**: 17
- **Taxonomies**: `139310_category` (gerarchica), `139310_tag` (non gerarchica)

## Campi

- **di concessione** (`di_concessione`): ddm-documentlibrary
- **Nominativo beneficiario** (`Nominativo_beneficiario`): text
- **HTML** (`HTML4099`): ddm-text-html
- **P.IVA. o C.F.** (`P_IVA__o_C_F_`): text
- **HTML** (`HTML4537`): ddm-text-html
- **Importo del vantaggio economico** (`Importo_del_vantaggio_economico`): text
- **HTML** (`HTML4318`): ddm-text-html
- **Norma o titolo a base dell'attribuzione** (`Norma_o_titolo_a_base_dell_attribuzione`): text
- **HTML** (`HTML4973`): ddm-text-html
- **Ufficio** (`Ufficio`): text
- **HTML** (`HTML4757`): ddm-text-html
- **Funzionario o Dirigente Responsabile del procedimento** (`Funzionario_o_Dirigente_Responsabile_del_procedimento`): text
- **HTML** (`HTML5510`): ddm-text-html
- **Modalità seguita per individuazione del beneficiario** (`Modalità_seguita_per_individuazione_del_beneficiario`): text
- **HTML** (`HTML5725`): ddm-text-html
- **Progetto selezionato** (`Progetto_selezionato`): text
- **HTML** (`HTML5942`): ddm-text-html
