# StrutturaConsiglioMetropolitano

Custom Post Type generato da DDMStructure: `1243107`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1243107`
- **Campi personalizzati**: 41
- **Taxonomies**: `1243107_category` (gerarchica), `1243107_tag` (non gerarchica)

## Campi

- **Data** (`Data_Pubblicazione`): ddm-date
- **Data di pubblicazione** (`Data_Di_Pubblicazione`): checkbox
- **Ultimo Aggiornamento** (`Ultimo_Aggiornamento`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Nome Allegato** (`Allegato_AN`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto`): checkbox
- **Nome Allegato** (`NA_Curriculum`): text
- **Allegato** (`Allegato13652`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto13917`): checkbox
- **Nome Allegato** (`Nome_Allegato30952`): text
- **Allegato** (`Allegato30652`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto30917`): checkbox
- **Nome Allegato** (`Nome_Allegato29650`): text
- **Allegato** (`Allegato29350`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto29615`): checkbox
- **Nome Allegato** (`Nome_Allegato28333`): text
- **Allegato** (`Allegato28033`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto28298`): checkbox
- **Nome Allegato** (`Nome_Allegato27016`): text
- **Allegato** (`Allegato26716`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto26981`): checkbox
- **Nome Allegato** (`Nome_Allegato24382`): text
- **Allegato** (`Allegato24082`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto24347`): checkbox
- **Nome Allegato** (`Nome_Allegato23065`): text
- **Allegato** (`Allegato22765`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto23030`): checkbox
- **Nome Allegato** (`Nome_Allegato21748`): text
- **Allegato** (`Allegato21448`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto21713`): checkbox
- **Nome Allegato** (`Nome_Allegato20431`): text
- **Allegato** (`Allegato20131`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto20396`): checkbox
- **Nome Allegato** (`Nome_Allegato52839`): text
- **Allegato** (`Allegato52539`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto52804`): checkbox
- **Nome Allegato** (`Nome_Allegato16599`): text
- **Allegato** (`Allegato16299`): ddm-documentlibrary
- **Allegato Nascosto** (`Allegato_Nascosto16564`): checkbox
