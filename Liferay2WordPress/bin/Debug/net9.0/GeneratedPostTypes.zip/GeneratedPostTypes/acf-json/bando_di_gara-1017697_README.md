# Bando di gara

Custom Post Type generato da DDMStructure: `1017697`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1017697`
- **Campi personalizzati**: 24
- **Taxonomies**: `1017697_category` (gerarchica), `1017697_tag` (non gerarchica)

## Campi

- **Sottotitolo** (`Sottotitolo`): text
- **Data** (`Data_Pubblicazione`): ddm-date
- **Data di pubblicazione** (`Data_Di_Pubblicazione`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Contenuto breve** (`Abstract`): ddm-text-html
- **Contenuto Esteso** (`Contenuto_Esteso`): ddm-text-html
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno`): text
- **Cig** (`Cig`): textarea
- **Struttura Proponente** (`Struttura_Proponente`): textarea
- **Procedura Scelta** (`Procedura_Scelta`): textarea
- **Elenco Operatori** (`Elenco_Operatori`): textarea
- **Aggiudicatario** (`Aggiudicatario`): textarea
- **Data Inizio** (`Data_Inizio`): ddm-date
- **Data Fine** (`Data_Fine`): ddm-date
- **Data Inizio** (`Data_Inizio_boolean`): checkbox
- **Data Fine** (`Data_Fine_boolean`): checkbox
- **Determina a contrarre** (`Determina_A_Contrarre`): textarea
- **Determina di aggiudicazione** (`Determina_Di_Aggiudicazione`): textarea
- **Importo di aggiudicazione** (`Importo_Aggiudicazione`): ddm-decimal
- **Importo delle somme liquidate** (`Importo_Somme_Liquidate`): ddm-decimal
