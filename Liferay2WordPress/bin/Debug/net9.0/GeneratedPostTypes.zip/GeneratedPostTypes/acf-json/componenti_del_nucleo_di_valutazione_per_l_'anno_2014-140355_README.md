# Componenti del nucleo di Valutazione per l\'anno 2014

Custom Post Type generato da DDMStructure: `140355`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `140355`
- **Campi personalizzati**: 4
- **Taxonomies**: `140355_category` (gerarchica), `140355_tag` (non gerarchica)

## Campi

- **Nominativo** (`Nominativo`): ddm-text-html
- **Ruolo** (`Ruolo`): ddm-text-html
- **Curriculum Vitae** (`Curriculum_Vitae`): ddm-text-html
- **Compenso Lordo** (`Compenso_Lordo`): ddm-text-html
