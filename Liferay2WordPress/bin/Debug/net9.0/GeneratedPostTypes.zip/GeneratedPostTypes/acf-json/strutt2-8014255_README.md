# Strutt2

Custom Post Type generato da DDMStructure: `8014255`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `8014255`
- **Campi personalizzati**: 0
- **Taxonomies**: `8014255_category` (gerarchica), `8014255_tag` (non gerarchica)

## Campi

