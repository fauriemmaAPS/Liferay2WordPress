# Albo Pretorio

Custom Post Type generato da DDMStructure: `17193`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `17193`
- **Campi personalizzati**: 13
- **Taxonomies**: `17193_category` (gerarchica), `17193_tag` (non gerarchica)

## Campi

- **Crea nuovo numero di pubblicazione** (`Pubblicazione`): checkbox
- **Contenuto** (`Contenuto`): ddm-text-html
- **Numero Protocollo** (`Numero_Protocollo`): text
- **Data Protocollo** (`Data_Protocollo`): ddm-date
- **Data Pubblicazione** (`Data_inizio_validita`): ddm-date
- **Data Fine Pubblicazione** (`Data_scadenza`): ddm-date
- **Tipologia** (`Tipologia`): text
- **Ente Proponente** (`Ente`): text
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Allegato Esterno** (`Allegato_Esterno`): text
- **Link** (`Link`): text
- **Nascondi dagli albi** (`scaduto`): checkbox
