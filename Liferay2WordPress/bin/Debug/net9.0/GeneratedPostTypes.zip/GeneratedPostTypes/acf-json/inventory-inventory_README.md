# Inventory

Custom Post Type generato da DDMStructure: `INVENTORY`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `inventory`
- **Campi personalizzati**: 6
- **Taxonomies**: `inventory_category` (gerarchica), `inventory_tag` (non gerarchica)

## Campi

- **Description** (`description`): textarea
- **Item** (`item`): text
- **Location** (`location`): text
- **Purchase Date** (`purchaseDate`): ddm-date
- **Purchase Price** (`purchasePrice`): ddm-number
- **Quantity** (`quantity`): ddm-number
