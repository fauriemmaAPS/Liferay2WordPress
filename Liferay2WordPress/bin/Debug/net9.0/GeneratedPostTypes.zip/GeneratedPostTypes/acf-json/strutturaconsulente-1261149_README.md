# StrutturaConsulente

Custom Post Type generato da DDMStructure: `1261149`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1261149`
- **Campi personalizzati**: 26
- **Taxonomies**: `1261149_category` (gerarchica), `1261149_tag` (non gerarchica)

## Campi

- **Estremi dell'atto di conferimento dell'incarico** (`Estremi_Atto`): textarea
- **Oggetto** (`Oggetto`): text
- **Normativa di riferimento** (`Norma_Titolo`): textarea
- **Data inizio incarico** (`Durata_Dal`): ddm-date
- **senza data inizio** (`senza_data_inizio`): checkbox
- **Data fine incarico** (`Durata_Al`): ddm-date
- **senza data fine** (`senza_data_fine`): checkbox
- **Compenso Lordo (€)** (`Importo`): ddm-decimal
- **Componenti variabili del compenso o legate alla valutazione di risultato (€)** (`Compenso_Variabile`): ddm-decimal
- **Svolgimento di incarichi o titolarità di cariche in enti di diritto privato regolati o finanziati dalla P.A. o relativi allo svolgimento di attività professionali (€)** (`Compenso_Incarichi`): ddm-decimal
- **Data Pubblicazione** (`Data_Pubblicazione`): ddm-date
- **Data di Pubblicazione** (`Data_di_Pubblicazione`): checkbox
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): text
- **Attestazioni art.53, comma 14 d.lgs 165/2001** (`Nome_Allegato_Attestazioni`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno`): text
- **Soggetto - Link al Curriculum vitae** (`Nome_Allegato_cv`): text
- **Allegato** (`Allegato_cv`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento_cv`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno_cv`): text
- **Allegato** (`Nome_Allegato_Generico`): text
- **Allegato** (`Allegato_Generico`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento_Generico`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno_Generico`): text
