# nuovo rdf

Custom Post Type generato da DDMStructure: `3680950`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `3680950`
- **Campi personalizzati**: 11
- **Taxonomies**: `3680950_category` (gerarchica), `3680950_tag` (non gerarchica)

## Campi

- **HTML** (`HTML3521`): ddm-text-html
- **Identificazione** (`dc11_identifier`): text
- **Titolo** (`dc11_title`): text
- **Genere** (`dc11_type`): text
- **Materia e tecnica** (`DCTerms_Medium`): textarea
- **Dimensioni** (`dcterms_format`): textarea
- **Secolo** (`dc11_date`): textarea
- **Autore** (`dc11_creator`): textarea
- **Uri** (`dcterms_source`): text
- **Linguaggio** (`dcterms_language`): textarea
- **Licenza** (`dc11_right`): textarea
