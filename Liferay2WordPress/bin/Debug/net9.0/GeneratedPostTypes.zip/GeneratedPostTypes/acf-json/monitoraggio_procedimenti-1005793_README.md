# monitoraggio_procedimenti

Custom Post Type generato da DDMStructure: `1005793`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1005793`
- **Campi personalizzati**: 53
- **Taxonomies**: `1005793_category` (gerarchica), `1005793_tag` (non gerarchica)

## Campi

- **Direzione (inserire nel titolo il contenuto di questo campo)** (`direzione`): select
- **Segretario Generale** (`option13038`): option
- **(Direzione Gestione Contenzioso Amministrativo) Direzione Legale 3** (`option7904`): option
- **Amministrativa Patri(Direzione Gestione Contenzioso Civile) Direzione Legale 2** (`option6010`): option
- **(Direzione Gestione Contenzioso Lavoro / Penale) Direzione Legale 4** (`option7906`): option
- **Controllo Strategico - Capo di Gabinetto** (`option7907`): option
- **Corpo di Polizia Provinciale** (`option7908`): option
- **Direzione Affari Generali - Flussi Documentali** (`option7909`): option
- **Direzione Amministrativa - Gestione Funzionamento Edifici Scolastici di 2° Grado** (`option7910`): option
- **Direzione Amministrativa Ambiente** (`option7911`): option
- **Direzione Amministrativa del Patrimonio / Prevenzione e Protezione / Rete Telefonica Fissa e Mobile** (`option7912`): option
- **Direzione Amministrativa Viabilità** (`option7913`): option
- **Direzione Attività Produttive (Turismo, Commercio, Artigianato, Agricoltura)** (`option7914`): option
- **Direzione Autorizzazione e Controllo Del Trasporto** (`option7915`): option
- **Direzione Cilo Integrato dei Rifiuti Tutela del Suolo Bonifica Siti, Risorse Idriche** (`option7916`): option
- **Direzione del Consiglio** (`option7917`): option
- **Direzione della Giunta** (`option7918`): option
- **Direzione Diritto allo Studio / Educazione Permanente** (`option7919`): option
- **Direzione Finanze, Investimenti, Tributi Investimenti e Patto di Stabilità** (`option7920`): option
- **Direzione Gestione Bilancio, Rendicontazione Bilancio Consolidato Contabilità** (`option7921`): option
- **Direzione Innovazione Organizzativa (CUG, Pari Opportunità Supporto ai Comuni Strandard di Qualità)** (`option7922`): option
- **Direzione Interventi Edilizia Scolastica I** (`option7923`): option
- **Direzione Interventi Edilizia Scolastica II** (`option7924`): option
- **Direzione Interventi Viabilità** (`option7925`): option
- **Direzione Mobilità Metropolitana** (`option7926`): option
- **Direzione Partecipate Controllo Analogo** (`option7927`): option
- **Direzione Patrocinio Innanzi alle Giurisdizioni Superiori - Consulenze e Pareri dell'Ente.** (`option7928`): option
- **Direzione Pianificazione delle Reti di Trasporto** (`option7929`): option
- **Direzione Pianificazione Territoriale e delle Reti Infrastrutturali** (`option7930`): option
- **Direzione Politiche del Lavoro - Servizi per l'Impiego, Immigrazione, Osservatorio Mercato del Lavoro** (`option7931`): option
- **Direzione Politiche del Personale - Implementazione dell'Organizzazione in Materia di Enti Locali.** (`option7932`): option
- **Direzione Politiche per la Sicurezza** (`option7933`): option
- **Direzione Progettazione Edilizia Scolastica** (`option7934`): option
- **Direzione Progettazione Viabilità** (`option7935`): option
- **Direzione Programmazione della Rete Scolastica Relativa alle Scuole** (`option7936`): option
- **Direzione Programmazione e Controllo Equilibri Finanziari** (`option7937`): option
- **Direzione Provveditorato, Economato** (`option7938`): option
- **Direzione Sanzioni** (`option7939`): option
- **Direzione Sistema Informativo ed Innovazione Tecnologica / Reti Telefoniche** (`option7940`): option
- **Direzione Solidarietà Sociale, Interventi per le Famiglie, Politiche Giovanili** (`option7941`): option
- **Direzione Stazione Unica Appalti, Servizi, Contratti** (`option7942`): option
- **Direzione Strutturazione e Pianificazione dei Servizi Pubblici di Interesse Generale di Ambito Metropolitano** (`option7943`): option
- **Direzione Tecnica del Patrimonio** (`option7944`): option
- **Direzione Trattamento Giuridico, Economico e Previdenziale del Personale** (`option7945`): option
- **Direzione Tutela delle Coste - Risorsa Mare** (`option7946`): option
- **Descrizione procedimento (Cliccare iconcina + per aggiungere un nuovo procedimento)** (`Descrizione_procedimento`): ddm-text-html
- **Responsabile** (`Responsabile`): textarea
- **Numero totale delle pratiche** (`Numero_di_procedimenti_conclusi`): ddm-integer
- **Tempo massimo stabilito di durata del procedimento** (`Termine_previsto_per_legge`): ddm-integer
- **Numero totale pratiche che hanno superato il limite prefissato** (`Numero_di_giorni_di_sospensione`): ddm-integer
- **Motivo sforamento tempi** (`Motivo_sforamento_tempi`): textarea
- **% delle pratiche che hanno superato il limite prefissato** (`Giorni_oltre_il_termine_previsto`): ddm-integer
- **Tempo medio di durata del procedimento** (`Media_giorni_di_ritardo`): ddm-integer
