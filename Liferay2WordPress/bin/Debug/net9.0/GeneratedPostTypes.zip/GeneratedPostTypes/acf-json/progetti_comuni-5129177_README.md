# Progetti Comuni

Custom Post Type generato da DDMStructure: `5129177`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `5129177`
- **Campi personalizzati**: 11
- **Taxonomies**: `5129177_category` (gerarchica), `5129177_tag` (non gerarchica)

## Campi

- **Comune** (`Comune`): textarea
- **Codice Progetto** (`Codice_progetto`): text
- **Livello di progettazione** (`Livello_di_progettazione`): textarea
- **Titolo del progetto** (`Titolo_del_progetto`): textarea
- **Importo finanziato da CM** (`Importo_finanziato_da_CM`): ddm-decimal
- **Importo totale intervento** (`Importo_totale_progetto`): ddm-decimal
- **Importo Cofinanziato** (`Importo_cofinanziato`): ddm-decimal
- **Importo Speso** (`Importo_speso`): ddm-decimal
- **Asse Piano Strategico** (`Asse_piano_strategico`): text
- **Azione Piano Strategico** (`Azione_piano_strategico`): text
- **Termine ultimazione previsto** (`Termine_ultimazione_previsto`): ddm-date
