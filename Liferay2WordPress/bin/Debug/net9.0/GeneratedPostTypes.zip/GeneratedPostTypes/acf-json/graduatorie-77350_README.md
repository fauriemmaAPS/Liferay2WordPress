# Graduatorie

Custom Post Type generato da DDMStructure: `77350`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `77350`
- **Campi personalizzati**: 3
- **Taxonomies**: `77350_category` (gerarchica), `77350_tag` (non gerarchica)

## Campi

- **Lista 1** (`Lista_1`): ddm-text-html
- **Definizione ai sensi del D.M. 471/99** (`Definizione_ai_sensi_del_D_M__471_99`): ddm-text-html
- **Definizione ai sensi del D.Lgs. 152/06** (`Definizione_ai_sensi_del_D_Lgs__152_06`): ddm-text-html
