# To Do

Custom Post Type generato da DDMStructure: `TO DO`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `to_do`
- **Campi personalizzati**: 17
- **Taxonomies**: `to_do_category` (gerarchica), `to_do_tag` (non gerarchica)

## Campi

- **Assigned To** (`assignedTo`): text
- **Attachment** (`attachment`): ddm-documentlibrary
- **Comments** (`comments`): textarea
- **Description** (`description`): textarea
- **End Date** (`endDate`): ddm-date
- **% Complete** (`percentComplete`): ddm-integer
- **Severity** (`severity`): select
- **Critical** (`critical`): option
- **Major** (`major`): option
- **Minor** (`minor`): option
- **Trivial** (`trivial`): option
- **Start Date** (`startDate`): ddm-date
- **Status** (`status`): select
- **Open** (`open`): option
- **Pending** (`pending`): option
- **Completed** (`completed`): option
- **Title** (`title`): text
