# Issues Tracking

Custom Post Type generato da DDMStructure: `ISSUES TRACKING`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `issues_tracking`
- **Campi personalizzati**: 16
- **Taxonomies**: `issues_tracking_category` (gerarchica), `issues_tracking_tag` (non gerarchica)

## Campi

- **Assigned To** (`assignedTo`): text
- **Attachment** (`attachment`): ddm-documentlibrary
- **Comments** (`comments`): textarea
- **Description** (`description`): textarea
- **Due Date** (`dueDate`): ddm-date
- **Issue ID** (`issueId`): text
- **Severity** (`severity`): select
- **Critical** (`critical`): option
- **Major** (`major`): option
- **Minor** (`minor`): option
- **Trivial** (`trivial`): option
- **Status** (`status`): select
- **Open** (`open`): option
- **Pending** (`pending`): option
- **Completed** (`completed`): option
- **Title** (`title`): text
