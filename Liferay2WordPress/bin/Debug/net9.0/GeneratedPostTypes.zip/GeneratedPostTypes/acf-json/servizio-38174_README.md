# Servizio

Custom Post Type generato da DDMStructure: `38174`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `38174`
- **Campi personalizzati**: 20
- **Taxonomies**: `38174_category` (gerarchica), `38174_tag` (non gerarchica)

## Campi

- **Avviso** (`Avviso`): ddm-text-html
- **Informazioni** (`Informazioni`): ddm-text-html
- **Orari apertura al pubblico** (`Orari_apertura_al_pubblica`): ddm-text-html
- **Chi può effettuare la richiesta** (`Chi_puo_effettuare_la_richiesta`): ddm-text-html
- **Modalità di presentazione** (`Modalita_di_presentazione`): ddm-text-html
- **Prescrizioni** (`Prescrizioni`): ddm-text-html
- **Termini per la presentazione** (`Termini_per_la_presentazione`): ddm-text-html
- **Documenti da consegnare** (`Documenti_da_consegnare`): ddm-text-html
- **Modalità di rilascio** (`Modalita_di_rilascio`): ddm-text-html
- **Ritiro** (`Ritiro`): ddm-text-html
- **Validità** (`Validita`): ddm-text-html
- **Eventuali costi** (`Eventuali_costi`): ddm-text-html
- **Normativa di riferimento** (`Normativa_di_riferimento`): ddm-text-html
- **Proprietà** (`Proprieta`): text
- **Testo** (`Testo`): ddm-text-html
- **Collegameto a pagina** (`Collegameto_a_pagina`): checkbox
- **Testo da visualizzare** (`Testo_da_visualizzare`): text
- **URL (Es. "http://www.google.com")** (`Url`): text
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
