# PNRR_scuole

Custom Post Type generato da DDMStructure: `10154040`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `10154040`
- **Campi personalizzati**: 4
- **Taxonomies**: `10154040_category` (gerarchica), `10154040_tag` (non gerarchica)

## Campi

- **Titolo del progetto** (`Titolo_del_progetto`): textarea
- **CUP** (`CUP`): text
- **Misura PNRR** (`Misura`): textarea
- **Importo** (`Importo`): ddm-number
