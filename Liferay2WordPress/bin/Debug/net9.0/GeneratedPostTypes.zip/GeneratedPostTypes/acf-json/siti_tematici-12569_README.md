# Siti Tematici

Custom Post Type generato da DDMStructure: `12569`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `12569`
- **Campi personalizzati**: 3
- **Taxonomies**: `12569_category` (gerarchica), `12569_tag` (non gerarchica)

## Campi

- **Immagine** (`Immagine`): ddm-documentlibrary
- **Testo** (`Testo`): text
- **Link** (`Link`): text
