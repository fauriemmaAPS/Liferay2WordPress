# PNRR_scuole_sismico

Custom Post Type generato da DDMStructure: `10220251`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `10220251`
- **Campi personalizzati**: 4
- **Taxonomies**: `10220251_category` (gerarchica), `10220251_tag` (non gerarchica)

## Campi

- **Scuola** (`scuola`): textarea
- **Titolo del progetto** (`Titolo_del_progetto`): textarea
- **CUP** (`CUP`): text
- **Misura PNRR** (`Misura`): textarea
