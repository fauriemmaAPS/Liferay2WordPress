# progetti comuni

Custom Post Type generato da DDMStructure: `4325270`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `4325270`
- **Campi personalizzati**: 13
- **Taxonomies**: `4325270_category` (gerarchica), `4325270_tag` (non gerarchica)

## Campi

- **Comune** (`Comune`): textarea
- **Codice Progetto** (`Codice_Progetto`): text
- **Titolo del progetto** (`Titolo_del_progetto`): textarea
- **Descrizione** (`Descrizione`): text
- **Importo totale intervento** (`Importo_totale_intervento`): ddm-number
- **Importo finanziato da CM** (`Importo_finanziato_da_CM`): ddm-number
- **Stato di avanzamento** (`Stato_di_avanzamento`): text
- **Termine lavori previsto** (`Termine_lavori_previsto`): text
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno`): text
- **Allegato Nascosto** (`Allegato_Nascosto`): checkbox
