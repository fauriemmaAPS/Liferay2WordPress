# Servizio Viabilità

Custom Post Type generato da DDMStructure: `1654308`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1654308`
- **Campi personalizzati**: 11
- **Taxonomies**: `1654308_category` (gerarchica), `1654308_tag` (non gerarchica)

## Campi

- **Cosa sono** (`cosa_sono`): ddm-text-html
- **Cosa fare** (`cosa_fare`): ddm-text-html
- **Chi può effettuare la richiesta** (`chi_può_effetturare_la_richiesta`): ddm-text-html
- **Modalità di presentazione** (`modalità_di_presentazione`): ddm-text-html
- **Costi** (`costi`): ddm-text-html
- **Informazioni** (`informazioni`): textarea
- **Collegameto a pagina** (`Collegameto_a_pagina`): checkbox
- **Testo da visualizzare** (`Testo_da_visualizzare`): text
- **URL (Es. "http://www.google.com")** (`Url`): text
- **Nome Allegato** (`Nome_Allegato`): text
- **Allegato** (`Allegato`): ddm-documentlibrary
