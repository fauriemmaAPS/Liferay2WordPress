# registro degli accessi

Custom Post Type generato da DDMStructure: `1722811`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `1722811`
- **Campi personalizzati**: 14
- **Taxonomies**: `1722811_category` (gerarchica), `1722811_tag` (non gerarchica)

## Campi

- **id** (`id`): ddm-integer
- **tipo** (`Seleziona2953`): select
- **accesso 241/90** (`option4628`): option
- **accesso civico** (`option4629`): option
- **accesso civico generalizzato** (`option4630`): option
- **oggetto** (`oggetto`): textarea
- **data della richiesta** (`data_della_richiesta`): ddm-date
- **Esito** (`Esito`): select
- **** (`option5646`): option
- **accoglimento** (`option6825`): option
- **diniego** (`option6826`): option
- **differimento** (`option6827`): option
- **limitazione** (`option6828`): option
- **data della decisione** (`data_della_decisione`): ddm-date
