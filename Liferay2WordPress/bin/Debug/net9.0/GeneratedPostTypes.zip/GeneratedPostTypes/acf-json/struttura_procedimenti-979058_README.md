# struttura procedimenti

Custom Post Type generato da DDMStructure: `979058`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `979058`
- **Campi personalizzati**: 105
- **Taxonomies**: `979058_category` (gerarchica), `979058_tag` (non gerarchica)

## Campi

- **Data di creazione** (`data_di_creazione`): ddm-date
- **Data di modifica** (`Data_di_modifica`): ddm-date
- **Riferimenti normativi utili** (`riferimenti_normativi_utili`): ddm-text-html
- **Area** (`area`): select
- **-** (`option8442`): option
- **Sindaco Metropolitano** (`option16061`): option
- **Consiglio Metropolitano** (`option16062`): option
- **Conferenza Metropolitana** (`option16063`): option
- **Segretario Generale** (`option16064`): option
- **Amministrativa Edilizia Istituzionale, Mobilità e Viabilità** (`option12364`): option
- **Affari istituzionali, Gare, Stazione Unica Appaltante** (`option12365`): option
- **Avvocatura** (`option7583`): option
- **Pianificazione Territoriale, Urbanistica, Sviluppo – Valorizzazione e Tutela Ambientale** (`option12366`): option
- **Risorse Umane, Innovazione e Qualità dei Servizi, Pari Opportunità** (`option12367`): option
- **Servizi Finanziari** (`option7588`): option
- **Tecnica Edilizia Istituzionale, Mobilità e Viabilità** (`option12368`): option
- **Corpo di Polizia Metropolitana** (`option12369`): option
- **Direzione Pianificazione Strategica e Politiche Comunitarie** (`option12370`): option
- **Direzione** (`direzione`): select
- **-** (`option10201`): option
- **Segretario Generale** (`option13038`): option
- **Pianificazione dei servizi e delle reti di trasporto** (`option13865`): option
- **Amministrativa Patrimonio – Provveditorato** (`option13866`): option
- **Amministrativa Scuole e Programmazione Scolastica** (`option13867`): option
- **Amministrativa Strade e Viabilità** (`option13042`): option
- **Supporto Organi istituzionali, Sindaco, Consiglio e Conferenza metropolitana, Affari Generali, Flussi Documentali, Anticorruzione, Trasparenza, Controlli** (`option13868`): option
- **Gare e Contratti dell’Ente, Espropri, SUA** (`option13869`): option
- **Legale 1** (`option13870`): option
- **Legale 2** (`option13871`): option
- **Pianificazione Territoriale – Urbanistica** (`option13872`): option
- **Ambiente, Sviluppo del territorio, Sanzioni** (`option13873`): option
- **politiche del personale, pari opportunità, qualità dei servizi** (`option13874`): option
- **Trattamento Giuridico, Economico e Previdenziale** (`option7483`): option
- **Sistemi Informativi integrati** (`option13875`): option
- **programmazione finanziaria e bilancio** (`option13876`): option
- **Contabilità ed Economato e Tributi** (`option13877`): option
- **Partecipazioni e Controllo Analogo** (`option7488`): option
- **Programmazione finanziaria e bilancio** (`option7485`): option
- **progettazione – progetti speciali** (`option13878`): option
- **Gestione Tecnica del Patrimonio** (`option13879`): option
- **Gestione Tecnica Edilizia Scolastica** (`option7491`): option
- **Gestione Tecnica Strade e Viabilità** (`option7492`): option
- **CORPO POLIZIA METROPOLITANA** (`option13880`): option
- **Pianificazione strategica e politiche comunitarie** (`option13881`): option
- **Funzioni Statali e Regionali** (`option7495`): option
- **Responsabile del procedimento (indicare anche recapiti telefonici e mail istituzionale)** (`responsabile_del_procedimento`): textarea
- **organo competente** (`organo_competente`): select
- **-** (`option5292`): option
- **Consiglio** (`option5288`): option
- **Dirigente** (`option5290`): option
- **Sindaco** (`option5291`): option
- **Tipologia di atto finale** (`tipologia_atto_finale`): select
- **** (`option11055`): option
- **Abilitazione** (`option12031`): option
- **Approvazione** (`option12032`): option
- **Assegnazione** (`option12033`): option
- **Attestato** (`option12034`): option
- **Attestazione** (`option12035`): option
- **Atto** (`option12036`): option
- **Autorizzazione/diniego** (`option12037`): option
- **Certificazione** (`option12038`): option
- **Concessione** (`option12039`): option
- **Decreto** (`option12040`): option
- **Deliberazione** (`option12041`): option
- **Determinazione** (`option12042`): option
- **Iscrizione** (`option12043`): option
- **Licenza** (`option12044`): option
- **Nulla Osta** (`option12045`): option
- **Parere** (`option12046`): option
- **Revoca** (`option12047`): option
- **Tesserino** (`option12048`): option
- **Modalità con le quali gli interessati possono ottenere le informazioni relative ai procedimenti in corso che li riguardino** (`modalita_informazioni`): textarea
- **termine per la conclusione del procedimento (giorni)** (`termine_giorni`): ddm-integer
- **Indicare le ragioni per termini superiori ai 90 giorni** (`ragioni_per_termini_superiori_ai_90_giorni`): textarea
- **prevista dichiarazione sostitutiva?** (`prevista_dichiarazione_sostitutiva`): checkbox
- **previsto il silenzio/assenso?** (`previsto_silenzio_assenso`): checkbox
- **Strumenti di tutela amministrativa e giurisdizionale** (`strumenti_di_tutela`): ddm-text-html
- **Modalità per l'effettuazione dei pagamenti** (`modalita_per_l_effettuazione_dei_pagamenti`): textarea
- **Identificativi del pagamento** (`identificativi_del_pagamento`): textarea
- **soggetto a cui è attribuito il potere sostitutivo** (`soggetto_potere_sostitutivo`): textarea
- **avvio del procedimento** (`avvio_procedimento`): select
- **-** (`option4195`): option
- **a richiesta** (`option4193`): option
- **d'ufficio** (`option4194`): option
- **Risultato delle indagini di customer satisfaction** (`customer_satisfaction`): textarea
- **Per informazioni** (`per_informazioni`): textarea
- **A rischio corruzione?** (`A_rischio_corruzione_`): checkbox
- **Area di rischio** (`Area_di_rischio`): select
- **-** (`option15110`): option
- **Acquisizione e progressione del personale** (`option14714`): option
- **Contratti pubblici (già Macro area affidamento di lavori, servizi e forniture...)** (`option14715`): option
- **Provvedimenti ampliativi della sfera giuridica dei destinatari privi di effetto economico diretto ed immediato per il destinatario** (`option14716`): option
- **Provvedimenti ampliativi della sfera giuridica dei destinatari con effetto economico diretto ed immediato per il destinatario** (`option14717`): option
- **Gestione delle entrate, delle spese e del patrimonio** (`option15111`): option
- **Controlli, verifiche, ispezioni e sanzioni (già Macro area attività di controllo e irrogazione di sanzioni...)** (`option14718`): option
- **Incarichi e nomine** (`option14719`): option
- **Affari legali e contenzioso** (`option15114`): option
- **Smaltimento dei rifiuti** (`option14720`): option
- **Pianificazione urbanistica** (`option15116`): option
- **Note** (`note`): ddm-text-html
- **Allegato** (`Nome_Allegato`): text
- **** (`Allegato`): ddm-documentlibrary
- **Collegamento alla Pagina** (`Collegamento`): ddm-link-to-page
- **Collegamento Esterno** (`Collegamento_Esterno`): text
- **Collegamento alla pagina di accesso al servizio online** (`link_servizio`): ddm-link-to-page
