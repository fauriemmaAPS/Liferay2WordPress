# Menu a Tendina (generico)

Custom Post Type generato da DDMStructure: `38592`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `38592`
- **Campi personalizzati**: 3
- **Taxonomies**: `38592_category` (gerarchica), `38592_tag` (non gerarchica)

## Campi

- **Titolo** (`Titolo`): text
- **Contenuto** (`Contenuto`): ddm-text-html
- **Form** (`Form`): checkbox
