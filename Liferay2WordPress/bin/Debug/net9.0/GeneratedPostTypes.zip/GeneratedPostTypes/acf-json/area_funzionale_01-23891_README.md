# Area Funzionale 01

Custom Post Type generato da DDMStructure: `23891`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `23891`
- **Campi personalizzati**: 13
- **Taxonomies**: `23891_category` (gerarchica), `23891_tag` (non gerarchica)

## Campi

- **Urp On Line** (`Inviaci_una_segnalazione`): ddm-link-to-page
- **Scrivici o Telefona** (`Appuntamento_telefonico`): ddm-link-to-page
- **Telefonaci** (`Telefonaci`): ddm-link-to-page
- **Segnala su mappa** (`Segnala_su_mappa`): text
- **I centri per l'impiego** (`I_centri_per_l_impiego`): ddm-link-to-page
- **Offerte di lavoro** (`Offerte_di_lavoro`): ddm-link-to-page
- **Istanze on line** (`Politiche_del_lavoro`): ddm-link-to-page
- **Canale Youtube** (`Canale_Youtube`): text
- **Immagine** (`Immagine`): text
- **Titolo Banner Immagine** (`Titolo_Banner_Immagine`): text
- **Titolo Link Immagine** (`Titolo_Link_Immagine`): text
- **Link WebTv** (`Link_WebTv`): text
- **Collegamento Immagine** (`Collegamento_Immagine`): ddm-link-to-page
