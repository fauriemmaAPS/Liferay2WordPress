# Events

Custom Post Type generato da DDMStructure: `EVENTS`

## Installazione

1. Installa e attiva il plugin **Advanced Custom Fields PRO**
2. Copia la cartella `acf-json` nel tuo tema WordPress
3. ACF registrerà automaticamente i Custom Post Types e le Taxonomies
4. Vai su Impostazioni → Permalinks e clicca Salva per aggiornare i permalink

## Struttura

- **Slug**: `events`
- **Campi personalizzati**: 7
- **Taxonomies**: `events_category` (gerarchica), `events_tag` (non gerarchica)

## Campi

- **Attachment** (`attachment`): ddm-documentlibrary
- **Cost** (`cost`): ddm-number
- **Description** (`description`): textarea
- **Date** (`eventDate`): ddm-date
- **Event Name** (`eventName`): text
- **Time** (`eventTime`): text
- **Location** (`location`): text
